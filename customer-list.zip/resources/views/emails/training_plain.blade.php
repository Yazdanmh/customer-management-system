New Training Application Received

Name: {{ $name }}
Email: {{ $email }}
Organization: {{ $organization }}
Phone: {{ $phone }}
Position: {{ $position }}
Address: {{ $address ?? 'N/A' }}
Identity Card ID: {{ $identity_card_id }}
Training Name: {{ $trainingName }}

Message:
Please review the application and contact the participant if necessary.

Best regards,
The Zahin Oxus Team
