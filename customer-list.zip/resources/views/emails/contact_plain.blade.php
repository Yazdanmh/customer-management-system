New Contact Form Submission

Name: {{ $name }}
Email: {{ $email }}

Message:
{{ $messageContent }}
