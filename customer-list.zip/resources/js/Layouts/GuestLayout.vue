<script setup >
</script>

<template>
  <slot></slot>
</template>
