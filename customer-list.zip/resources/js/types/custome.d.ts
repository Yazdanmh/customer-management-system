// types/custom.d.ts

declare module 'aos' {
    const AOS: any;
    export default AOS;
  }
  
  declare module 'wow.js' {
    const WOW: any;
    export default WOW;
  }
  